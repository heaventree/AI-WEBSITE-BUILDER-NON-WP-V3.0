<?php

namespace App\Http\Middleware;

use Common\Core\Middleware\TrustProxies as Middleware;

class TrustProxies extends Middleware
{
  //
}
